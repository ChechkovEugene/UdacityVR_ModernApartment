# Udacity VRND course Project 2 Modern apartment

The goal is to design and create own apartment based on several given 3D models.
Also project has to have some globe animation and adequate lighting with baking

## Content

Unity project which can be build by user for the iOs or Android and uploaded on the phone

## Use
Download project and GoogleVR SDK _You can find link in google search_. Drag
GoogleVR prefab to the scene and export to the platform which you need


### Prerequisities
Mobile Phone,
Google Cardboard HMD,
GoogleVR SDK for add to the project

![Screenshot](https://github.com/ChechkovEugene/UdacityVR_ModernApartment/blob/master/Screenshots/Screenshot_2017-01-18-16-36-55.png "Screenshot")
